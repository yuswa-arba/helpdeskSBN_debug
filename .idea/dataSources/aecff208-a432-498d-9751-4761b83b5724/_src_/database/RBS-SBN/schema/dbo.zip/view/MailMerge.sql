
CREATE VIEW MailMerge AS
SELECT (Select Count(*) From BillsSections
        Where BillIndex = a.BillIndex And
              Type <> 7 And
              BillSectionIndex > a.BillSectionIndex) AS IsLast,
       (Select Sum(Charge) From BillsSections
        Where BillIndex = a.BillIndex) AS Sums,
       (Select Sum(Charge) From BillsSections
        Where BillIndex=a.BillIndex And Type = 7) AS Tax,
       a.*,
       b.BillStartDate, b.BillEndDate, b.CreateDate As BillCreateDate,
       c.UserID, c.GroupName, c.UserPaymentBalance,
       d.*,
       e.ServiceName
FROM (((BillsSections AS a
        LEFT JOIN Bills AS b ON a.BillIndex = b.BillIndex)
        LEFT JOIN Users AS c ON b.UserIndex = c.UserIndex)
        LEFT JOIN UserDetails AS d ON c.UserIndex = d.UserIndex)
        LEFT JOIN Services AS e ON a.Info1 = e.ServiceIndex
WHERE b.BillType = 1 And a.Type <> 7
