CREATE VIEW dbo.view_billing
AS
SELECT     dbo.BillingTransactions.BillingTransactionIndex, dbo.BillingTransactions.CreateDate, dbo.BillingTransactions.UserType, 
                      dbo.BillingTransactions.UserIndex, dbo.BillingTransactions.TransType, dbo.BillingTransactions.Reference, dbo.BillingTransactions.Total, 
                      dbo.Payments.PaymentNumber, dbo.Bills.BillIndex, dbo.Users.UserID, dbo.Users.Password, dbo.Users.PasswordDate, dbo.Users.PasswordSource, 
                      dbo.Users.GroupName, dbo.Users.UserService, dbo.Users.UserIP, dbo.Users.FilterName, dbo.Users.StartDate, dbo.Users.UserExpiryDate, 
                      dbo.Users.ManualExpirationDate, dbo.Users.SuspendDate, dbo.Users.UserActive, dbo.Users.AccountIndex, dbo.Users.UserTimeBank, 
                      dbo.Users.UserKBBank, dbo.Users.UserDollarBank, dbo.Users.UserBalance, dbo.Users.UserPaymentBalance, dbo.Users.TimeOnline, 
                      dbo.Users.CallBackNumber, dbo.Users.CallerID, dbo.Users.Lockout, dbo.Users.LockoutTime, dbo.Users.LockoutCount, 
                      dbo.Users.GracePeriodExpiration, dbo.Users.NASAttributes
FROM         dbo.BillingTransactions LEFT OUTER JOIN
                      dbo.Users ON dbo.Users.UserIndex = dbo.BillingTransactions.UserIndex LEFT OUTER JOIN
                      dbo.Bills ON dbo.Bills.BillIndex = dbo.BillingTransactions.Reference AND dbo.BillingTransactions.TransType = 1 LEFT OUTER JOIN
                      dbo.Payments ON dbo.Payments.PaymentNumber = dbo.BillingTransactions.Reference AND dbo.BillingTransactions.TransType = 2
